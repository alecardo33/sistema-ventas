import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabaseClient';

interface Usuario {
  id: string;
  nombre: string;
  email?: string;
  rol: 'Admin' | 'Vendedor' | 'Contabilidad';
  estado: 'activo' | 'inactivo';
}

export default function ConfiguracionUsuarios() {
  const [usuarios, setUsuarios] = useState<Usuario[]>([]);
  const [cargando, setCargando] = useState<boolean>(true);

  // Cargar usuarios desde Supabase
  useEffect(() => {
    obtenerUsuarios();
  }, []);

  const obtenerUsuarios = async () => {
    try {
      setCargando(true);
      const { data, error } = await supabase
        .from('usuarios')
        .select('*');

      if (error) throw error;
      if (data) setUsuarios(data as Usuario[]);
    } catch (error) {
      console.error('Error al cargar usuarios:', error);
    } finally {
      setCargando(false);
    }
  };

  // Cambiar Rol
  const handleRolChange = async (userId: string, nuevoRol: Usuario['rol']) => {
    try {
      const { error } = await supabase
        .from('usuarios')
        .update({ rol: nuevoRol })
        .eq('id', userId);

      if (error) throw error;

      setUsuarios(prev =>
        prev.map(u => (u.id === userId ? { ...u, rol: nuevoRol } : u))
      );
    } catch (error) {
      console.error('Error al actualizar rol:', error);
    }
  };

  // Cambiar Estado (Activar/Desactivar)
  const handleToggleEstado = async (userId: string, estadoActual: Usuario['estado']) => {
    const nuevoEstado = estadoActual === 'activo' ? 'inactivo' : 'activo';
    try {
      const { error } = await supabase
        .from('usuarios')
        .update({ estado: nuevoEstado })
        .eq('id', userId);

      if (error) throw error;

      setUsuarios(prev =>
        prev.map(u => (u.id === userId ? { ...u, estado: nuevoEstado } : u))
      );
    } catch (error) {
      console.error('Error al actualizar estado:', error);
    }
  };

  // FUNCIÓN: Eliminar Usuario
  const handleEliminarUsuario = async (userId: string, nombre: string) => {
    const confirmado = window.confirm(
      `¿Estás seguro de que deseas eliminar permanentemente a "${nombre || 'este usuario'}"?`
    );

    if (!confirmado) return;

    try {
      const { error } = await supabase
        .from('usuarios')
        .delete()
        .eq('id', userId);

      if (error) throw error;

      // Actualizar estado local
      setUsuarios(prev => prev.filter(u => u.id !== userId));
    } catch (error) {
      console.error('Error al eliminar usuario:', error);
      alert('No se pudo eliminar el usuario. Es posible que tenga registros o ventas asociadas.');
    }
  };

  if (cargando) {
    return <div className="p-6 text-gray-500">Cargando usuarios...</div>;
  }

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {/* Encabezado */}
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Usuarios</h1>
        <button
          onClick={() => console.log('Abrir modal nuevo usuario')}
          className="bg-slate-900 hover:bg-slate-800 text-white font-medium px-4 py-2 rounded-lg transition-colors"
        >
          + Nuevo usuario
        </button>
      </div>

      {/* Lista de usuarios */}
      <div className="space-y-3">
        {usuarios.map(usuario => (
          <div
            key={usuario.id}
            className="flex items-center justify-between p-4 bg-white border border-slate-200 rounded-xl shadow-sm"
          >
            <div>
              <div className="font-semibold text-slate-800">
                {usuario.nombre || 'Sin nombre'}
              </div>
              <span
                className={`inline-block text-xs px-2.5 py-0.5 rounded-full font-medium mt-1 ${
                  usuario.estado === 'activo'
                    ? 'bg-green-100 text-green-800'
                    : 'bg-slate-100 text-slate-600'
                }`}
              >
                {usuario.estado}
              </span>
            </div>

            <div className="flex items-center gap-2">
              {/* Selector de Rol */}
              <select
                value={usuario.rol || 'Admin'}
                onChange={e => handleRolChange(usuario.id, e.target.value as Usuario['rol'])}
                className="px-3 py-1.5 border border-slate-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-slate-400"
              >
                <option value="Admin">Admin</option>
                <option value="Vendedor">Vendedor</option>
                <option value="Contabilidad">Contabilidad</option>
              </select>

              {/* Botón Activar / Desactivar */}
              <button
                onClick={() => handleToggleEstado(usuario.id, usuario.estado)}
                className="px-3 py-1.5 border border-slate-300 text-slate-700 rounded-lg text-sm hover:bg-slate-50 transition-colors"
              >
                {usuario.estado === 'activo' ? 'Desactivar' : 'Activar'}
              </button>

              {/* BOTÓN ELIMINAR */}
              <button
                onClick={() => handleEliminarUsuario(usuario.id, usuario.nombre)}
                className="px-3 py-1.5 bg-red-50 border border-red-200 text-red-700 font-medium rounded-lg text-sm hover:bg-red-100 transition-colors"
              >
                Eliminar
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}